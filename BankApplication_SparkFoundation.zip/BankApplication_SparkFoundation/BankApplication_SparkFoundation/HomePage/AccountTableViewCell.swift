//
//  AccountTableViewCell.swift
//  BankApplication_SparkFoundation
//
//  Created by Akrit Awasthi on 7/11/21.
//  Copyright © 2021 Akrit Awasthi. All rights reserved.
//

import UIKit

class AccountTableViewCell: UITableViewCell {

    @IBOutlet weak var holderName: UILabel!
    @IBOutlet weak var emailID: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
    func setData(data: UserDetails){
        holderName.text = data.accountHolderName
        emailID.text = data.emailId
    }
    func setDataSender(data: SenderDetails){
        holderName.text = data.accountHolderName
        emailID.text = data.emailId
    }
    
}
