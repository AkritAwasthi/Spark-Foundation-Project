//
//  ReceiverDetailsVC.swift
//  BankApplication_SparkFoundation
//
//  Created by Akrit Awasthi on 7/11/21.
//  Copyright © 2021 Akrit Awasthi. All rights reserved.
//

import UIKit

class ReceiverDetailsVC: UIViewController {

    var receiverData                : UserDetails?
    var senderData                  : SenderDetails?
    var isSender                    : Bool = false

    @IBOutlet weak var lblBalance      : UILabel!
    @IBOutlet weak var lblName      : UILabel!
    @IBOutlet weak var lblemailID   : UILabel!
    @IBOutlet weak var lblAccountNumber   : UILabel!
    @IBOutlet weak var lblMobileNumber   : UILabel!
    @IBOutlet weak var lblIfscCode   : UILabel!
    @IBOutlet weak var btnSendMoney      : UIButton!

    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if isSender{
            self.title = "Sender Details"
            btnSendMoney.isHidden = true
            lblBalance.isHidden = false
            lblBalance.text = "Account Balance     ::: \(senderData?.currentBalance ?? 0) Rs"
            lblName.text = senderData?.accountHolderName
            lblemailID.text = senderData?.emailId
            lblAccountNumber.text = senderData?.accountNumber
            lblMobileNumber.text = senderData?.mobileNumber
            lblIfscCode.text = senderData?.ifscCode
        }
        else {
            self.title = "Beneficiary Details"
            lblBalance.isHidden = true
            btnSendMoney.isHidden = false
            lblName.text = receiverData?.accountHolderName
            lblemailID.text = receiverData?.emailId
            lblAccountNumber.text = receiverData?.accountNumber
            lblMobileNumber.text = receiverData?.mobileNumber
            lblIfscCode.text = receiverData?.ifscCode
        }
        
    }
    
    
    @IBAction func sendMoney(_ sender: Any) {
        let transactionDetailsVC: TransactionDetailsVC = TransactionDetailsVC.instantiate(appStoryboard: .main)
        transactionDetailsVC.senderData = senderData
        transactionDetailsVC.receiverData = receiverData
        self.navigationController?.pushViewController(transactionDetailsVC, animated:true)
    }
    

}
