//
//  TransactionDetailsVC.swift
//  BankApplication_SparkFoundation
//
//  Created by Akrit Awasthi on 7/11/21.
//  Copyright © 2021 Akrit Awasthi. All rights reserved.
//

import UIKit

class TransactionDetailsVC: UIViewController {

    var receiverData                        : UserDetails?
    var senderData                          : SenderDetails?
    var enteredValue                        : Int?
    
    
    @IBOutlet weak var lblNameSender        : UILabel!
    @IBOutlet weak var lblSenderBalance     : UILabel!
    @IBOutlet weak var lblNamebenifit       : UILabel!
    @IBOutlet weak var lblAccountNumber     : UILabel!
    @IBOutlet weak var lblIfscCode          : UILabel!
    @IBOutlet weak var txtFieldAmount       : UITextField!

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Transaction Details"
        lblNameSender.text = senderData?.accountHolderName
        lblSenderBalance.text = "\(senderData?.currentBalance ?? 0) Rs"
        lblNamebenifit.text = receiverData?.accountHolderName
        lblAccountNumber.text = receiverData?.accountNumber
        lblIfscCode.text = receiverData?.ifscCode
    }
    
    
    @IBAction func transferMoney(_ sender: Any) {
        
        if enteredValue ?? 0 > senderData?.currentBalance ?? 0 {
            let alert = UIAlertController(title: "Alert", message: "Entered Amount is Greater than Current Balance", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        else {
            let alert = UIAlertController(title: "Successfully", message: "\(enteredValue ?? 0) Rs transfered in Beneficiary Account", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: { action in
                self.navigationController?.popToRootViewController(animated: true)
                
            }))
            self.present(alert, animated: true, completion: nil)
            senderData?.currentBalance = (senderData?.currentBalance ?? 0) - (enteredValue ?? 0)
        }
       }

}

extension TransactionDetailsVC: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        enteredValue = Int(textField.text ?? "0")
    }
}
