//
//  ViewController.swift
//  BankApplication_SparkFoundation
//
//  Created by Akrit Awasthi on 7/11/21.
//  Copyright © 2021 Akrit Awasthi. All rights reserved.
//

import UIKit

struct UserDetails {
    let accountHolderName   : String
    let emailId             : String
    let currentBalance      : Int
    let accountNumber       : String
    let mobileNumber        : String
    let ifscCode            : String
}

class SenderDetails {
    var accountHolderName   : String
    var emailId             : String
    var currentBalance      : Int
    var accountNumber       : String
    var mobileNumber        : String
    var ifscCode            : String
    
    init(accountHolderName: String, emailId: String, currentBalance: Int, accountNumber: String, mobileNumber: String, ifscCode: String){
        self.accountHolderName = accountHolderName
        self.emailId = emailId
        self.currentBalance = currentBalance
        self.accountNumber = accountNumber
        self.mobileNumber = mobileNumber
        self.ifscCode = ifscCode
    }
    
}



class ViewController: UIViewController {

    // MARK: - Properties -
    @IBOutlet weak var tblView  : UITableView!
    var updatedBalance          : Int?
    
    var senderAccountdetails: Array = [SenderDetails(accountHolderName: "Akrit Awasthi", emailId: "akritawasthi123@gmail.com", currentBalance: 30000, accountNumber: "123456789", mobileNumber: "9876543212", ifscCode: "HDFC2345T")]
    
    var receiverAccountdetails: Array = [UserDetails(accountHolderName: "Vaibhava Bajpai", emailId: "bajpai@gmail.com", currentBalance: 500000, accountNumber: "123456789", mobileNumber: "9876543212", ifscCode: "HDFC2345T"),
                                         
                                         UserDetails(accountHolderName: "Akrit Bajpai", emailId: "awasthi@gmail.com", currentBalance: 2000, accountNumber: "987654321", mobileNumber: "9876542345", ifscCode: "SBI2345T"),
                                         
                                         UserDetails(accountHolderName: "Aastha Sinha", emailId: "sinhastha@gmail.com", currentBalance: 1000000, accountNumber: "1234545632", mobileNumber: "9876756446", ifscCode: "PNB2345T"),
                                         
                                         UserDetails(accountHolderName: "Himangi Shelar", emailId: "shelar@gmail.com", currentBalance: 200000, accountNumber: "1325457686", mobileNumber: "9864524565", ifscCode: "SBI2345T"),
                                         
                                         UserDetails(accountHolderName: "Vaidehi Mishra", emailId: "vaid@gmail.com", currentBalance: 600000, accountNumber: "87644567666", mobileNumber: "9867554543", ifscCode: "HDFC2345T"),
                                         
                                         UserDetails(accountHolderName: "Ishika Awasthi", emailId: "ishika@gmail.com", currentBalance: 20000, accountNumber: "12365654545", mobileNumber: "988754343", ifscCode: "PNB2345T"),
                                         
                                         UserDetails(accountHolderName: "Arvika Bajpai", emailId: "arvika@gmail.com", currentBalance: 2000, accountNumber: "123432545", mobileNumber: "9876756375", ifscCode: "HDFC2345T"),
                                         
                                         UserDetails(accountHolderName: "Manu Awasthi", emailId: "manu@gmail.com", currentBalance: 10000, accountNumber: "15334246576", mobileNumber: "97656457655", ifscCode: "HDFC2345T"),
                                         
                                         UserDetails(accountHolderName: "Anshika Awasthi", emailId: "anshika@gmail.com", currentBalance: 200000, accountNumber: "1286535443", mobileNumber: "98342567767", ifscCode: "SBI2345T"),
                                         
                                         UserDetails(accountHolderName: "Anushka Sharma", emailId: "anu@gmail.com", currentBalance: 20000, accountNumber: "12645456575", mobileNumber: "98732776745", ifscCode: "HDFC2345T")]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblView.register(UINib.init(nibName: "AccountTableViewCell", bundle: nil), forCellReuseIdentifier: "AccountTableViewCell")
    }
    
    override func viewDidAppear(_ animated: Bool) {
    }
}


// MARK: - Extension TableView -
extension ViewController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0{
            return senderAccountdetails.count
        }
        else{
            return receiverAccountdetails.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "AccountTableViewCell", for: indexPath) as! AccountTableViewCell
        cell.selectionStyle = .none
        if indexPath.section == 0{
            cell.setDataSender(data: senderAccountdetails[0])
        }
        else{
            cell.setData(data: receiverAccountdetails[indexPath.row])
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    func tableView( _ tableView : UITableView,  titleForHeaderInSection section: Int)->String? {
       switch(section) {
         case 0: return "Sender Account Details"
         default : return "Benefeciery Account Details"
       }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let receiverDetailsVC: ReceiverDetailsVC = ReceiverDetailsVC.instantiate(appStoryboard: .main)
        
        if indexPath.section == 0{
            receiverDetailsVC.isSender = true
        }
        else {
            receiverDetailsVC.receiverData = receiverAccountdetails[indexPath.row]
        }
        receiverDetailsVC.senderData = senderAccountdetails[0]
        self.navigationController?.pushViewController(receiverDetailsVC,animated:true)
    }
    
}

extension UIViewController {
    class func instantiate<T: UIViewController>(appStoryboard: AppStoryboard) -> T {
        let storyboard = UIStoryboard(name: appStoryboard.rawValue, bundle: nil)
        let identifier = String(describing: self)
        return storyboard.instantiateViewController(withIdentifier: identifier) as! T
    }
}
enum AppStoryboard: String {
    case main = "Main"
}
